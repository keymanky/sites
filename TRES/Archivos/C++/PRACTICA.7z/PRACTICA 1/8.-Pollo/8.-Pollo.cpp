#include <iostream.h>
#include <conio.h>
#include <graphics.h>
#include <dos.h>



class Pollo
{
	private:
		int circulo[7];		//7=n*3+1 donde n es el numero de circulos q tiene la figura
		int elipse[5];		//5=n*3+1 donde n es el numero de elipses q tiene la figura
		int triangulo[16];	//16=n*5+1 donde n es el numero de cu�as circulares q tiene la figura
		int linea[17];		//77=n*4+1 donde n es el numero de lineas q tiene la figura
		int rectangulo[5];	//5=n*4+1 donde n es el numero de rectangulos q tiene la figura
		int ver;
		int xp,yp;

	public:
		Pollo(int, int);
		void Dibuja();
		void Oculta();
		void Mueve(int, int);
		void Nueva_Pos(int,int);
		void Mueve_Pies(int);
		//void Camina(int);
};


Pollo :: Pollo (int x=0, int y=0)
{

	int i;
	for(i=0;i<=0;i++)	//ciclo q inicializa el subindice cero de todos los arreglos a cero (No utilizar tal subindice)
	{
	circulo[i]=0;
	elipse[i]=0;
	triangulo[i]=0;
	linea[i]=0;
	rectangulo[i]=0;
	}


	//componentes de un circulo (ojo)(los subinidices son: 1=x,2=y,3=radio, se creo el arreglo con el objetivo de no usar tantas variables se sigue la misma logica para cada arreglo)
	circulo[1]=16+x;
	circulo[2]=17+y;
	circulo[3]=5;

	//componentes del 2do circulo(cabeza)
	circulo[4]=14+x;
	circulo[5]=23+y;
	circulo[6]=13;

	//componentes elipse(panza) (1=x,2=y,3=radio en x,4=radio en y)
	elipse[1]=15+x;
	elipse[2]=52+y;
	elipse[3]=7;
	elipse[4]=10;

	//componentes del rectangulo(cuello)(1=x,2=y,3=x+base,4=y+base)
	rectangulo[1]=13+x;
	rectangulo[2]=35+y;
	rectangulo[3]=rectangulo[1]+5;
	rectangulo[4]=rectangulo[2]+8;

	//componente de las lineas (1=x1;2=y1;3=x2;4=y2)
	//(pata izquierda)
	linea[1]=12+x;
	linea[2]=55+y;
	linea[3]=12+x;
	linea[4]=75+y;
	//(pata derecha)
	linea[5]=17+x;
	linea[6]=55+y;
	linea[7]=17+x;
	linea[8]=75+y;
	//(pie izquierdo)
	linea[9]=12+x;
	linea[10]=75+y;
	linea[11]=14+x;
	linea[12]=75+y;
	//(pie derecho)
	linea[13]=17+x;
	linea[14]=75+y;
	linea[15]=19+x;
	linea[16]=75+y;

	//componentes de los triangulos (1=x,2=y,3=angulo inicial;4=angulo final;5=radio)
	//(cresta 1)
	triangulo[1]=7+x;
	triangulo[2]=0+y;
	triangulo[3]=270;
	triangulo[4]=315;
	triangulo[5]=10;
	//(cresta 2)
	triangulo[6]=14+x;
	triangulo[7]=3+y;
	triangulo[8]=270;
	triangulo[9]=315;
	triangulo[10]=7;
	//(Pico)
	triangulo[11]=30+x;
	triangulo[12]=20+y;
	triangulo[13]=135;
	triangulo[14]=225;
	triangulo[15]=3;

	ver=0;
	xp=x;			//guarda los puntos del pollo
	yp=y;
}



void 	Pollo ::Dibuja()
{
	circle(circulo[1],circulo[2],circulo[3]);
	circle(circulo[4],circulo[5],circulo[6]);
	fillellipse(elipse[1],elipse[2],elipse[3],elipse[4]);
	rectangle(rectangulo[1],rectangulo[2],rectangulo[3],rectangulo[4]);
	line(linea[1],linea[2],linea[3],linea[4]);
	line(linea[5],linea[6],linea[7],linea[8]);
	line(linea[9],linea[10],linea[11],linea[12]);
	line(linea[13],linea[14],linea[15],linea[16]);
	pieslice(triangulo[1],triangulo[2],triangulo[3],triangulo[4],triangulo[5]);
	pieslice(triangulo[6],triangulo[7],triangulo[8],triangulo[9],triangulo[10]);
	pieslice(triangulo[11],triangulo[12],triangulo[13],triangulo[14],triangulo[15]);

	ver=1;
}


void Pollo :: Nueva_Pos(int x,int y)
{
	//componentes de un circulo (ojo)(los subinidices son: 1=x,2=y,3=radio, se creo el arreglo con el objetivo de no usar tantas variables se sigue la misma logica para cada arreglo)
	circulo[1]=16+x;
	circulo[2]=17+y;
	circulo[3]=5;

	//componentes del 2do circulo(cabeza)
	circulo[4]=14+x;
	circulo[5]=23+y;
	circulo[6]=13;

	//componentes elipse(panza) (1=x,2=y,3=radio en x,4=radio en y)
	elipse[1]=15+x;
	elipse[2]=52+y;
	elipse[3]=7;
	elipse[4]=10;

	//componentes del rectangulo(cuello)(1=x,2=y,3=x+base,4=y+base)
	rectangulo[1]=13+x;
	rectangulo[2]=35+y;
	rectangulo[3]=rectangulo[1]+5;
	rectangulo[4]=rectangulo[2]+8;

	//componente de las lineas (1=x1;2=y1;3=x2;4=y2)
	//(pata izquierda)
	linea[1]=12+x;
	linea[2]=55+y;
	linea[3]=12+x;
	linea[4]=75+y;
	//(pata derecha)
	linea[5]=17+x;
	linea[6]=55+y;
	linea[7]=17+x;
	linea[8]=75+y;
	//(pie izquierdo)
	linea[9]=12+x;
	linea[10]=75+y;
	linea[11]=14+x;
	linea[12]=75+y;
	//(pie derecho)
	linea[13]=17+x;
	linea[14]=75+y;
	linea[15]=19+x;
	linea[16]=75+y;

	//componentes de los triangulos (1=x,2=y,3=angulo inicial;4=angulo final;5=radio)
	//(cresta 1)
	triangulo[1]=7+x;
	triangulo[2]=0+y;
	triangulo[3]=270;
	triangulo[4]=315;
	triangulo[5]=10;
	//(cresta 2)
	triangulo[6]=14+x;
	triangulo[7]=3+y;
	triangulo[8]=270;
	triangulo[9]=315;
	triangulo[10]=7;
	//(Pico)
	triangulo[11]=30+x;
	triangulo[12]=20+y;
	triangulo[13]=135;
	triangulo[14]=225;
	triangulo[15]=3;

	xp=x;
	yp=y;
	ver=0;
}


void Pollo::Oculta()
{
	unsigned guardacolor=getcolor();
	setcolor(getbkcolor());
	Dibuja();
	setcolor(guardacolor);
	ver=0;
}

void Pollo :: Mueve(int xn, int yn)
{
	if(ver)
	   Oculta();
	Nueva_Pos(xn,yn);
	Dibuja();
	ver=1;
}

void Pollo ::Mueve_Pies(int e=0)
{
	if(e==0)
	  Mueve(xp,yp);
	if(e==1)
	{
		Mueve(xp,yp);					//dibuje a estado  cero o normal
		unsigned guardacolor=getcolor();		//oculta parte derecha
		setcolor(getbkcolor());
		line(linea[5],linea[6],linea[7],linea[8]);
		line(linea[13],linea[14],linea[15],linea[16]);
		setcolor(guardacolor);
		//(pata derecha)
		linea[7]=19+xp;
		linea[8]=75+yp;
		//(pie derecho)
		linea[13]=19+xp;
		linea[14]=75+yp;
		linea[15]=21+xp;
		linea[16]=73+yp;
		setcolor(guardacolor);
		line(linea[5],linea[6],linea[7],linea[8]);	//dibuje de las nuevas patas
		line(linea[13],linea[14],linea[15],linea[16]);
	}
	if(e==2)
	{
		Mueve(xp,yp);					//dibuje a estado  cero o normal
		unsigned guardacolor=getcolor();		//oculta parte izquierda
		setcolor(getbkcolor());
		line(linea[1],linea[2],linea[3],linea[4]);
		line(linea[9],linea[10],linea[11],linea[12]);
		setcolor(guardacolor);

		//(pata izquierda)
		linea[3]=10+xp;
		linea[4]=73+yp;
		//(pie izquierdo)
		linea[9]=10+xp;
		linea[10]=73+yp;
		linea[11]=12+xp;
		linea[12]=75+yp;
		setcolor(guardacolor);
		line(linea[1],linea[2],linea[3],linea[4]);
		line(linea[9],linea[10],linea[11],linea[12]);
	}
	ver=1;
}

/*void Pollo::Camina(int n)
{
     int i,c=0;
     for(i=xp;i<n;i++,c++)
     {
	if(c==3)
		c=1;
	Mueve_Pies(c);
	if(i%3==0)
		Mueve(i,0);
	delay(50);
     }
}*/

void main()
{
     int a,b,i,c=0;
     Pollo P1,P2(0,100),P3(0,200);
     a=DETECT;
     initgraph(&a,&b," ");
     for(i=0;i<200;i++,c++)
     {
	if(c==3)
		c=1;
	P1.Mueve(i,0);
	P2.Mueve_Pies(c);
	P3.Mueve_Pies(c);
	if(i%3==0)
	{
	P3.Mueve(i,200);

	}
	delay(100);
	cleardevice();
     }



	outtextxy( 10, 400, "REALIZARON:  JORGE SALGADO MENDOZA,OMAR RODRIGUEZ ORDAZ");
	outtextxy( 10, 425, "keymanky@hotmail.com");
	outtextxy( 10, 450, "AGOSTO 2010, LIC. MAT APLI Y COMP. PROGRAMACION ORIENTADA A OBJETOS");
	getch();
     closegraph();
}
