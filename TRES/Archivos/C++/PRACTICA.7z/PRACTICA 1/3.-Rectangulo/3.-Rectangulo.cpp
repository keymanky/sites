#include<iostream.h>
#include<conio.h>
#include<dos.h>
#include<graphics.h>

class rectangulo
{
      private:
	      float base;
	      float altura;
	      float x,y;
	      int ver;
       public:
	      //inicia constructor
	      rectangulo(float ob=0,float oa=0,float ox=0,float oy=0)
	      {
		 base=ob;
		 altura=oa;
		 x=ox;
		 y=oy;
		 ver=0;
	      }
	      float area()
	      { return (base*altura);}
	      float perimetro()
	      {return (2*base+2*altura);}
	      void dibujar()
	      {
	      rectangle(x,y,x+base,y+altura);
	      ver=1;
	      }

	      void ocltar()
	      {
		    unsigned guardacolor;
		    guardacolor=getcolor();
		    setcolor(getbkcolor());
		    rectangle(x,y,x+base,y+altura);
		    ver=0;
		    setcolor(guardacolor);
	      }
	      void mover(float nx,float ny)
		    {
			 if(ver)
		    {
		       void ocultar();
			  x=nx;
			  y=ny;
			  dibujar();
		    }
		    else
		    {
			x=nx;
			y=ny;
		    }
	      }
};
	    // crear objeto

	    void main()
	    {
		 rectangulo rec1(300,150,50,100);
		 int i,a,b;
		 a=DETECT;
		 initgraph(&a,&b," ");
		 rec1.dibujar();
		 for(i=0; i<=300;i++)
		 {
		  cleardevice();
		  rec1.mover(100+i,120);
		  delay(50);
		 }
		 rec1.dibujar();
		 rec1.area();
		 getch();
		 closegraph;
	    }
