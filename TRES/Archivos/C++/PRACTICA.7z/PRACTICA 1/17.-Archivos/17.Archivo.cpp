#include<iostream.h>
#include<conio.h>
#include<stdio.h>
#include<string.h>
class Archivo
{
   private:
	  FILE *archivo;
	  char *nombre;
   public:
	  Archivo(char *);
	  void Crear();
	  void Elimina_Contenido();
	  void Abre();
	  void Imprime(int);
	  void Agrega(char *);
	  void Cierra();
	  void Elimina_Archivo();
};

Archivo :: Archivo (char *nom)
{
   strcpy(nombre,nom);
}
void Archivo :: Elimina_Contenido()
{
   archivo=fopen(nombre,"w");
   if(archivo==NULL)
      {
      cout<<"Error";
      return ;
      }
   else
      fclose(archivo);
}
void Archivo :: Abre()
{
  archivo=fopen(nombre,"a+");
  if(archivo==NULL)
      {
      cout<<"Error";
      return ;
      }
}
void Archivo :: Imprime(int n=0)
{
  char *nuevos;
  do{
  //fgets(nuevos,n,archivo);
  }while(fgets(nuevos,n,archivo)!=NULL);
  fflush(stdin);
  puts(nuevos);
  //cout<<nuevos;
}
void Archivo :: Agrega(char *nuevo)
{
   fputs(nuevo,archivo);
   fputc('\n',archivo);
}
void Archivo :: Crear ()
{
   archivo=fopen (nombre,"a");
   if(archivo==NULL)
      {
      cout<<"Error";
      return ;
      }
   else
      fclose(archivo);
}
void Archivo :: Cierra()
{
   fclose(archivo);
}
void Archivo :: Elimina_Archivo()
{
   fopen(nombre,"a");
   remove(nombre);
   fclose(archivo);
}
void main()
{
   clrscr();
   char *cad;
   int r;
   cout<<"Creamos un archivo Prueba"<<endl;
   Archivo Prueba("prueba");
   cout<<"Abrimos el archivo"<<endl;
   Prueba.Abre();
   cout<<"Que cadena quieres agregar"<<endl;
   cin>>cad;
   Prueba.Agrega(cad);
   Prueba.Imprime(50);
   Prueba.Cierra();
   cout<<"DESEA borra el archivo (si=1/no=0)";
   cin>>r;
   if(r==1)
      Prueba.Elimina_Archivo();
   getch();

}
