#include<stdio.h>
#include<iostream.h>
#include<conio.h>

typedef struct Cola
{
	int elemento;
	struct Cola *sig;
}c;

class Fila
{
      private:
	      c *inicio, *ultimo;
	      int elementos;
      public:
	      Fila();
	      void Agrega(int);
	      void Avanza(int);
	      void Elimina();
	      void Imprime(int);
	      int Busca(int);
	      void VerContenido();
	      ~Fila();

};

Fila :: Fila()
{
     inicio=NULL;
     ultimo=NULL;
     elementos=0;
}

void Fila :: Agrega(int nuevo=0)
{
     c *nuevop;
     if((nuevop=new c)!=NULL)
     {
	  nuevop->elemento=nuevo;
	  elementos +=1;
	  if(elementos==1)
	  {
	       inicio=nuevop;
	       inicio->sig=NULL;
	       ultimo=inicio;
	  }
	  else
	  {
	       ultimo->sig=nuevop;
	       ultimo=nuevop;
	  }
     }
     else
	  cout<<"Insuficiente Memoria";
}


void Fila :: Avanza(int n=0)
{
     int i;
     if(n<=elementos && n>0)
     {
	  for(i=0;i<=n-1;i++)
	  {
	       if(n==elementos && i==n-1)
		    ultimo=inicio->sig;
	       c *aux=inicio;
	       inicio=inicio->sig;
	       delete (aux);
	  }
     }
     elementos-=n;
}


void Fila :: Elimina()
{
     Avanza(elementos);
}

void Fila :: Imprime(int n=0)
{
     cout<<"El contenido de la fila es"<<endl;
     if(n<=elementos && n>0)
     {
	int i;
	c *aux=inicio;
	for(i=1;i<n;i++)
	     aux=aux->sig;
	cout<<"El elemento "<< n<<" es  "<<aux->elemento<<endl;
     }
     else
	cout<<"Ese elemento no existe"<<endl;
}

void Fila :: VerContenido()
{
     int n=elementos,i;
     for(i=1;i<=n;i++)
	 Imprime(i);
}


int Fila :: Busca (int n=0)
{
    c *aux=inicio;
    int i;
    for(i=1;i<=elementos;i++)
    {
	 if(aux->elemento == n)
	      return i;
	 aux=aux->sig;
    }
    return 0;
}

Fila :: ~Fila()
{
     Elimina();
}

void main()
{
     clrscr();
     int n,b;
     Fila Banco;
     do{
     cout<<"Dame el elemento q se agregara Para finalizar teclea el numero -1:"<<endl;
     cin>>n;
     Banco.Agrega(n);
     }while(n!=-1);
     cout<<"Los elementos anadidos son\n";
     Banco.VerContenido();
     cout<<"Cuantos elementos quieres que avancen de la Fila"<<endl;
     cin>>n;
     Banco.Avanza(n);
     Banco.VerContenido();
     cout<<"Que elemento quieres buscar"<<endl;
     cin>>n;
     b=Banco.Busca(n);
     Banco.Imprime(b);
getch();
}