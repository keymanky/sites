#include <iostream.h>
#include <conio.h>
#include <graphics.h>
#include <dos.h>
#include <math.h>
class Linea
{
      private:
	      int x,y,x2,y2,ver;
      public:
	      Linea(int, int, int,int);
	      int Distancia();
	      void Dibujar();
	      void Ocultar();
	      void Moverx(int);
	      void Movery(int);
	      void Expandex(int);
	      void Expandey(int);
};


Linea :: Linea(int ox=320,int oy=230, int ox2=320,int oy2=250)
	{
	      x=ox;
	      y=oy;
	      x2=ox2;
	      y2=oy2;
	      ver=0;
	}


int Linea :: Distancia()
	{
	      float distancia;
	      distancia=(x2-x)*(x2-x);
	      distancia=distancia-(y2-y)*(y2-y);
	      distancia=sqrt(distancia);
	      return (distancia);
	}


void Linea :: Dibujar()
	{
	      line(x,y,x2,y2);
	      ver=1;
	}


void Linea :: Ocultar()
	{
	      unsigned guardacolor;
	      guardacolor= getcolor();
	      setcolor(getbkcolor());
	      Dibujar();
	      ver=0;
	      setcolor(guardacolor);
	}


void Linea :: Moverx (int nx)
	{
	      if(ver)
		  Ocultar();
	      x=x+nx;
	      x2=x2+nx;
	      Dibujar();
	      ver=1;
	}

void Linea :: Movery (int ny)
	{
	      if(ver)
		  Ocultar();
	      y=x+ny;
	      y2=y2+ny;
	      Dibujar();
	      ver=1;
	}

void Linea :: Expandex(int e)
	{
	      Ocultar();
	      y=y-e;
	      //y2=y2+e;
	      Dibujar();
	      ver=1;
	}

void Linea :: Expandey(int e)
	{
	      Ocultar();
	      x=x-e;
	      Dibujar();
	      ver=1;
	}



void main()
{

     int a,b,i;
     a=DETECT;
     initgraph(&a,&b," ");

     Linea L1(0,150,0,200),L2(0,250,20,250);
     L1.Dibujar();
     L2.Dibujar();
     getch();
     for(i=1;i<640;i++)
     {
	L1.Moverx(1);
	L2.Moverx(1);
	if(i%10==0)
	    {
	    L1.Expandex(1);
	    L2.Expandey(1);
	    }
	delay(5);
     }
     getch();
     closegraph();
}
