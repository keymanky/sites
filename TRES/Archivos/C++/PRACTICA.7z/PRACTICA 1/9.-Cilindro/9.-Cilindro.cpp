#include<conio.h>
#include<graphics.h>
#include<stdlib.h>
#include<dos.h>

class Elipse
{
 private:

 float x,y,rx,ry;
 int ver;

 public:
  Elipse(float ox,float oy,float orx,float ory)
  {
    x=ox;
    y=oy;
    rx=orx;
    ry=ory;
    ver=0;
  }
   float darx()
   {return x;}
   float dary()
   {return y;}
   float darrx()
   {return rx;}
   float darry()
   {return ry;}

   void pintar()
   {
       fillellipse(x,y,rx,ry);
	 ver=1;
   }
   void ocultar()

   {
   unsigned gc=getcolor();
   setcolor(getbkcolor());
   fillellipse(x,y,rx,ry);
     ver=0;
   setcolor(gc);
   }
     void mover(int nx, int ny)
     { if (ver)
       {
       ocultar();
       x=nx;
       y=ny;
      pintar();
       }
      else
       {
       x=nx;
       y=ny;
       }
      }
  };

 class linea
 {
 private:
       float xi,yi,rxi,ryi;
       int ver;
 public:
	linea(float exi,float eyi,float erxi,float eryi)
	 {
	 xi=exi;
	 yi=eyi;
	 rxi=erxi;
	 ryi=eryi;
	 ver=0;
	 }
	 float darxi()
	 {return xi;}
	 float dary()
	 {return yi;}
	 float darrxi()
	 {return rxi;}
	 float darryi()
	 { return ryi;}
	 void pintar()

	 {
	      line(xi,yi,rxi,ryi);
	      ver=1;
	 }
	 void ocultar()
	      {
		   unsigned gc=getcolor();
		   setcolor(getbkcolor());
		   line(xi,yi,rxi,ryi);
		   ver=0;
		   setcolor(gc);

	      }
 };

void main()
  {
  int a,b,i,j;
  a=DETECT;
  initgraph(&a,&b," ");
  Elipse E1(100,30,50,10);
  Elipse E2(100,100,50,10);
  E1.pintar();
  E2.pintar();
  linea L1(50,30,50,100);
  linea L2(150,30,150,100);
  L1.pintar();
  L2.pintar();
  getch();
       getch();
  closegraph();
  }
