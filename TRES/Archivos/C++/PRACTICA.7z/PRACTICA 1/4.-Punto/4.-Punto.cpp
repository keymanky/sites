#include <iostream.h>
#include <conio.h>
#include <graphics.h>
#include <dos.h>

class Punto
{
      private:
	      int x,y,radio,ver,color;
      public:
	      Punto (int, int,int);
	      void Dibujar();
	      void Ocultar();
	      void Mover(int, int);
	      void Cambia_Tamano(int);
	      void Dar_Tamano();
	      void Dar_Color();
};


Punto :: Punto (int ox=320,int oy=240,int ocolor=2)
	{
	      radio=1;
	      x=ox;
	      y=oy;
	      ver=0;
	      color= ocolor;
	}

void Punto :: Dibujar()
	{
	      setcolor(color);
	      circle(x,y,radio);
	      ver=1;
	}


void Punto :: Ocultar()
	{
	      unsigned guardacolor;
	      guardacolor= getcolor();
	      setcolor(getbkcolor());
	      circle(x,y,radio);
	      ver=0;
	      setcolor(guardacolor);
	}


void Punto :: Mover(int nx,int ny)
	{
	      if(ver)
		  Ocultar();
	      x=nx;
	      y=ny;
	      Dibujar();
	      ver=1;
	}

void Punto :: Cambia_Tamano(int oo=0)
{
	radio=radio+oo;
}

void Punto :: Dar_Tamano()
{
	cout<<radio<<endl;
}

void Punto :: Dar_Color()
{
	cout<<color<<endl;
}
void main()
{

     int a,b,i;
     a=DETECT;
     Punto P1(639,240,2),P2(1,240,4),P3(320,240,3),P4(320,240,5),P5(320,240,6),P6(320,240,14),P7(320,240,12),P8(320,240,11),P9(320,240,10),P10(320,240,9);
     initgraph(&a,&b," ");

     P1.Dar_Color();
     P2.Dar_Tamano();
     getch();


     for(i=1;i<=320;i++)                 //ciclo que hace la colision
     {
	P2.Mover(i,240);
	P1.Mover(639-i,240);
	delay(5);
     }
     P1.Ocultar();
     P2.Ocultar();


					//ciclo que mueve las particulas resultantes de la colision
     for(i=1;i<=240;i++)
     {

	P3.Mover(320,240+i);
	P4.Mover(320,240-i);
	P5.Mover(320-i,240);
	P6.Mover(320+i,240);
	P7.Mover(320+i,240+i);
	P8.Mover(320-i,240-i);
	P9.Mover(320+i,240-i);
	P10.Mover(320-i,240+i);
	delay(5);
     }

     getch();
     closegraph();
}
