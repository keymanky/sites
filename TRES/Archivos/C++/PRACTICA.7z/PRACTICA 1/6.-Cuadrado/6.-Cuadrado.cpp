#include <iostream.h>
#include <conio.h>
#include <graphics.h>
#include <dos.h>

class Cuadrado
{
      private:
	      int x,y,lado,ver;
      public:
	      Cuadrado(int, int, int);
	      float Area();
	      float Perimetro();
	      void Dibujar();
	      void Ocultar();
	      void Mover(int, int);
	      void Expande(int);
};


Cuadrado :: Cuadrado(int ox=320-7,int oy=240-7, int olado=10)
	{
	      x=ox;
	      y=oy;
	      lado=olado;
	      ver=0;
	}


float Cuadrado :: Area()
	{
	      return (lado*lado);
	}


float Cuadrado ::Perimetro()
	{
	      return (4*lado);
	}


void Cuadrado :: Dibujar()
	{
	      rectangle(x,y,x+lado,y+lado);
	      ver=1;
	}


void Cuadrado :: Ocultar()
	{
	      unsigned guardacolor;
	      guardacolor= getcolor();
	      setcolor(getbkcolor());
	      Dibujar();
	      ver=0;
	      setcolor(guardacolor);
	}


void Cuadrado :: Mover(int nx,int ny)
	{
	      if(ver)
		  Ocultar();
	      x=nx;
	      y=ny;
	      Dibujar();
	      ver=1;
	}

void Cuadrado :: Expande(int e)
	{
	      Ocultar();
	      lado=lado+e;
	      Dibujar();
	      ver=1;
	}





void main()
{

     int a,b,i,j=1;
     a=DETECT;
     initgraph(&a,&b," ");

     Cuadrado C1,C2;

     for(i=1;i<640;i++)
     {
	C1.Mover(i,160);
	C2.Mover(640-i,320);
	if(i%50==0)
	    {
	    C1.Expande(j);
	    C2.Expande(j);
	    j++;
	    }
	delay(5);
     }
     getch();
     closegraph();
}
