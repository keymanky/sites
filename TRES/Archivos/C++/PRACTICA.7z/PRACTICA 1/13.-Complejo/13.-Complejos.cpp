#include<conio.h>
#include<iostream.h>
class Complejo
{
      private:
	      float real,ima;
      public:

//TODOS LOS OPERADORES SOBRE CARGADOS SON LOS SIGUIENTES FIJARSE BIEN



	      Complejo (float,float);                                               //contructor
	      Complejo Conjugado();                                         //conjugado de un complejo
	      /*****************SUMA***********************************************/
	      Complejo operator ++();

	      Complejo operator + (Complejo &);
	      Complejo operator + (float);
	      Complejo operator + (int);
	      Complejo operator + (double);

	      Complejo operator += (Complejo &);
	      Complejo operator += (float);
	      Complejo operator += (int);
	      Complejo operator += (double);

	      friend Complejo operator + (float, Complejo &);
	      friend Complejo operator + (int, Complejo &);
	      friend Complejo operator + (double, Complejo &);


	      /*****************RESTA***********************************************/
	      Complejo operator --();

	      Complejo operator - (Complejo &);
	      Complejo operator - (float);
	      Complejo operator - (int);
	      Complejo operator - (double);

	      Complejo operator -= (Complejo &);
	      Complejo operator -= (float);
	      Complejo operator -= (int);
	      Complejo operator -= (double);

	      friend Complejo operator - (float, Complejo &);
	      friend Complejo operator - (int, Complejo &);
	      friend Complejo operator - (double, Complejo &);


	      /*****************MULTIPLICACION*************************************/
	      Complejo operator * (Complejo &);
	      Complejo operator * (float);
	      Complejo operator * (int);
	      Complejo operator * (double);

	      Complejo operator *= (Complejo &);
	      Complejo operator *= (float);
	      Complejo operator *= (int);
	      Complejo operator *= (double);

	      friend Complejo operator * (float, Complejo &);
	      friend Complejo operator * (int, Complejo &);
	      friend Complejo operator * (double, Complejo &);

	      /*****************DIVISION********************************************/
	      Complejo operator / (Complejo &);
	      Complejo operator / (float);
	      Complejo operator / (int);
	      Complejo operator / (double);

	      Complejo operator /= (Complejo &);
	      Complejo operator /= (float);
	      Complejo operator /= (int);
	      Complejo operator /= (double);

	      friend Complejo operator / (float, Complejo &);
	      friend Complejo operator / (int, Complejo &);
	      friend Complejo operator / (double, Complejo &);

	      /*****************LOGICOS*********************************************/
	      Complejo operator = (Complejo &);
	      int operator == (Complejo &);
	      int operator != (Complejo &);
	      int operator >= (Complejo &);
	      int operator <= (Complejo &);
	      int operator > (Complejo &);
	      int operator < (Complejo &);


	      void Imprime();

};
//Constructor
	      Complejo :: Complejo (float a=0.0,float b=0.0)
	      {
		      real=a;
		      ima=b;
	      }
/************************REDIFINICION DE OPERADORES****************************/
//SUMA
	     Complejo Complejo :: operator ++()
	     {
		   real++;
		   ima++;
		   return (*this);
	     }

	      Complejo Complejo :: operator + (Complejo &x)
	      {
		       real=real+ x.real;
		       ima=ima + x.ima;
		       return Complejo(real,ima);
	      }
	      Complejo Complejo :: operator + (float n)
	      {
		       return Complejo (real + n, ima);
	      }
	      Complejo Complejo :: operator + (int n)
	      {
		       return Complejo (real + (float)n, ima);
	      }
	      Complejo Complejo :: operator + (double n)
	      {
		       return Complejo (real + (float)n, ima);
	      }

	      Complejo Complejo :: operator += (Complejo &x)
	      {
		real=real + x.real;
		ima= ima + x.ima;
		return(*this);
	      }
	      Complejo Complejo :: operator += (float x)
	      {
		real=real + x;
		return(*this);
	      }
	      Complejo Complejo :: operator += (int x)
	      {
		real=real + (float)x;
		return(*this);
	      }
	      Complejo Complejo :: operator += (double x)
	      {
		real=real + (float)x;
		return(*this);
	      }

//funciones amigas
	  Complejo operator +(float a, Complejo &x)
	  {
	       return Complejo (a+x.real, x.ima);
	  }
	  Complejo operator +(int a, Complejo &x)
	  {
	       return Complejo ((float)a+x.real, x.ima);
	  }
	  Complejo operator +(double a, Complejo &x)
	  {
	       return Complejo ((float)a+x.real, x.ima);
	  }
//RESTA
	  Complejo Complejo :: operator --()
	  {
		   real--;
		   ima--;
		   return (*this);
	  }

	      Complejo Complejo :: operator - (Complejo &x)
	      {
		       real=real- x.real;
		       ima=ima - x.ima;
		       return Complejo(real,ima);
	      }
	      Complejo Complejo :: operator - (float n)
	      {
		       return Complejo (real - n, ima);
	      }
	      Complejo Complejo :: operator - (int n)
	      {
		       return Complejo (real - (float)n, ima);
	      }
	      Complejo Complejo :: operator - (double n)
	      {
		       return Complejo (real - (float)n, ima);
	      }

	      Complejo Complejo :: operator -= (Complejo &x)
	      {
		real=real - x.real;
		ima= ima - x.ima;
		return(*this);
	      }
	      Complejo Complejo :: operator -= (float x)
	      {
		real=real - x;
		return(*this);
	      }
	      Complejo Complejo :: operator -= (int x)
	      {
		real=real - (float)x;
		return(*this);
	      }
	      Complejo Complejo :: operator -= (double x)
	      {
		real=real - (float)x;
		return(*this);
	      }

//funciones amigas
	  Complejo operator -(float a, Complejo &x)
	  {
	       return Complejo (a-x.real, x.ima);
	  }
	  Complejo operator -(int a, Complejo &x)
	  {
	       return Complejo ((float)a-x.real, x.ima);
	  }
	  Complejo operator -(double a, Complejo &x)
	  {
	       return Complejo ((float)a-x.real, x.ima);
	  }

//MULTIPLICACION
	      Complejo Complejo :: operator *(Complejo &x)
	      {
		       Complejo t;
		       t.real=(real * x.real)-(ima * x.ima);
		       t.ima= (real * x.ima) + (ima * x.real);
		       return Complejo(t.real,t.ima);
	      }
	      Complejo Complejo :: operator * (float n)
	      {
		       return Complejo (real*n, ima*n);
	      }
	      Complejo Complejo :: operator * (int n)
	      {
		       return Complejo (real*(float)n, ima*(float)n);
	      }
	      Complejo Complejo :: operator * (double n)
	      {
		       return Complejo (real * (float)n, ima * (float)n);
	      }

	      Complejo Complejo :: operator *= (Complejo &x)
	      {
	      real=(real * x.real)-(ima * x.ima);
	      ima= (real * x.ima) + (ima * x.real);
		  return(*this);
	      }
	      Complejo Complejo :: operator *= (float x)
	      {
	      real=real*x;
	      ima=ima*x;
		return(*this);
	      }
	      Complejo Complejo :: operator *= (int x)
	      {
	      real=real* (float)x;
	      ima= ima * (float)x;
		return(*this);
	      }
	      Complejo Complejo :: operator *= (double x)
	      {
		real=real * (float)x;
		ima=ima * (float)x;
		return(*this);
	      }

//funciones amigas
	  Complejo operator *(float a, Complejo &x)
	  {
	       return Complejo (a*x.real, a*x.ima);
	  }
	  Complejo operator *(int a, Complejo &x)
	  {
	       return Complejo ((float)a * x.real, (float)a* x.ima);
	  }
	  Complejo operator *(double a, Complejo &x)
	  {
	       return Complejo ((float)a * x.real, (float)a * x.ima);
	  }
//Conjugado
	  Complejo Complejo :: Conjugado()
	  {
	      return Complejo(real, -1 *ima);
	  }
//DIVISION
	      Complejo Complejo :: operator /(Complejo &x)
	      {
		       Complejo z3;//= (*this) * x.Conjugado;
		       z3=(*this);// * (x.Conjugado());
		       z3=z3 * (x.Conjugado());
	       Complejo z4= x * x.Conjugado();

	       //cout<<z3.real<<" "<<z3.ima<<" "<<z4.real<<" "<<z4.ima <<endl;

	       return Complejo(z3.real/z4.real, z3.ima/z4.real);
	      }
	      Complejo Complejo :: operator / (float n)
	      {
		       return Complejo (real/n, ima/n);
	      }
	      Complejo Complejo :: operator / (int n)
	      {
		       return Complejo (real/(float)n, ima/(float)n);
	      }
	      Complejo Complejo :: operator / (double n)
	      {
		       return Complejo (real / (float)n, ima / (float)n);
	      }

	      Complejo Complejo :: operator /= (Complejo &x)
	      {
	      Complejo z3= (*this) * x.Conjugado();
	      Complejo z4= x * x.Conjugado();
	      real=z3.real/z4.real;
	      ima=z3.ima/z4.ima;
		  return(*this);
	      }
	      Complejo Complejo :: operator /= (float x)
	      {
	      real=real/x;
	      ima=ima/x;
		  return(*this);
	      }
	      Complejo Complejo :: operator /= (int x)
	      {
	      real=real/ (float)x;
	      ima= ima / (float)x;
		return(*this);
	      }
	      Complejo Complejo :: operator /= (double x)
	      {
		real=real / (float)x;
		ima=ima / (float)x;
		return(*this);
	      }

//funciones amigas
	  Complejo operator /(float a, Complejo &x)
	  {
	       Complejo aa(a,0.0);
	       Complejo z1=aa * x.Conjugado();
	       Complejo z2=x * x.Conjugado();
	       return Complejo(z1.real/z2.real, z2.ima/z2.ima);
	  }
	  Complejo operator /(int a, Complejo &x)
	  {
	       Complejo aa((float)a,0.0);
	       Complejo z1=aa * x.Conjugado();
	       Complejo z2=x * x.Conjugado();
	       return Complejo(z1.real/z2.real, z2.ima/z2.ima);
	  }
	  Complejo operator /(double a, Complejo &x)
	  {
	       Complejo aa((float)a,0.0);
	       Complejo z1=aa * x.Conjugado();
	       Complejo z2=x * x.Conjugado();
	       return Complejo(z1.real/z2.real, z2.ima/z2.ima);
	  }

	      Complejo Complejo :: operator = (Complejo &x)
	      {
		       real=x.real;
		       ima=x.ima;
		       return Complejo(real,ima);
		       //return(*this);
	      }
	      void Complejo :: Imprime()
	      {
		       if(ima<0)
			       cout<<real <<ima<<"i"<<endl;
		       else
			       cout<<real <<"+"<<ima<<"i"<<endl;
	      }
	      int Complejo :: operator == (Complejo &x)
	      {
		       if(real==x.real && ima==x.ima)
			    return 1;
		       else
			    return 0;
	      }
	      int Complejo :: operator >= (Complejo &x)
	      {
		       if(real>=x.real && ima>=x.ima)
			    return 1;
		       else
			    return 0;
	      }
	      int Complejo :: operator <= (Complejo &x)
	      {
		       if(real<=x.real && ima<=x.ima)
			    return 1;
		       else
			    return 0;
	      }
	      int Complejo :: operator > (Complejo &x)
	      {
		       if(real>x.real && ima>x.ima)
			    return 1;
		       else
			    return 0;
	      }
	      int Complejo :: operator < (Complejo &x)
	      {
		       if(real<x.real && ima<x.ima)
			    return 1;
		       else
			    return 0;
	      }
	      int Complejo :: operator != (Complejo &x)
	      {
		       if(real != x.real && ima != x.ima)
			    return 1;
		       else
			    return 0;
	      }

void main()
{
     clrscr();
     float r1,r2;
     cout<<"ESTA ES LA CLASE COMPLEJO ACA ESTAN LA SOBRECARGA DE LOS OPERADORES CON INT, COMPLEJO,FLOAT Y DOUBLE, CON SUS FUNCIONES AMIGAS, ESTA ES UNA PEQUENA PRUEBA DE QUE SI FUNCIONAN (PARA VER TODOS LOS OPERADORES SOBRECARGADOS VER LA BIBLIOTECA"<<endl<<endl;
     cout<<"Dame la parte real del 1ER complejo  (C1):      ";
     cin>>r1;
     cout<<"Dame la parte imaginaria del 1ER complejo:      ";
     cin>>r2;
     Complejo C1(r1,r2);

     cout<<"Dame la parte real del 2DO complejo  (C2):      ";
     cin>>r1;
     cout<<"Dame la parte imaginaria del 2DO complejo:      ";
     cin>>r2;
     Complejo C2(r1,r2);
     Complejo C3;

     cout<<"El primer complejo es                           ";
     C1.Imprime();
     cout<<"El segundo complejo es                          ";
     C2.Imprime();
     if(C1<C2)
       cout<<"EL primer complejo es mayor"<<endl;
     else
       cout<<"El segundo complejo es mayor"<<endl;
     cout<<"El C1++                                         ";
     C1++;
     C1.Imprime();
     cout<<"El C2--                                         ";
     C2--;
     C2.Imprime();
     cout<<"El C1+=C2 es                                    ";
     C1+=C2;
     C1.Imprime();
     cout<<"El Complejo C3=10.4-C2  es                      ";
     float a=10.4;
     C3=a-C2;
     C3.Imprime();
     cout<<"El conjugado de C2 es (guardamos este en C3)    ";
     C3=C2.Conjugado();
     C3.Imprime();
     cout<<"El resultado de C3/=5 es                        ";
     C3/=5;
     C3.Imprime();
     cout<<"El resultado de C1/C2 es                        ";
     C3=C1/C2;
     C3.Imprime();
     cout<<"C1 *  C2 es                                     ";
     C3=C1*C2;
     C3.Imprime();
     cout<<"C2*= C2 es                                      ";
     C2*=C2;
     C2.Imprime();
     getch();
}
