#include <iostream.h>
#include <conio.h>
#include <graphics.h>
#include <dos.h>
#include <math.h>
class Linea
{
      private:
	      int x,y,x2,y2,ver;
      public:
	      Linea(int, int, int,int);
	      int Distancia();
	      void Dibujar();
	      void Ocultar();
	      void Moverx(int);
	      void Movery(int);
	      void Expandex(int);
	      void Expandey(int);
};


Linea :: Linea(int ox=320,int oy=230, int ox2=320,int oy2=250)
	{
	      x=ox;
	      y=oy;
	      x2=ox2;
	      y2=oy2;
	      ver=0;
	}


int Linea :: Distancia()
	{
	      float distancia;
	      distancia=(x2-x)*(x2-x);
	      distancia=distancia-(y2-y)*(y2-y);
	      distancia=sqrt(distancia);
	      return (distancia);
	}


void Linea :: Dibujar()
	{
	      line(x,y,x2,y2);
	      ver=1;
	}


void Linea :: Ocultar()
	{
	      unsigned guardacolor;
	      guardacolor= getcolor();
	      setcolor(getbkcolor());
	      Dibujar();
	      ver=0;
	      setcolor(guardacolor);
	}


void Linea :: Moverx (int nx)
	{
	      if(ver)
		  Ocultar();
	      x=x+nx;
	      x2=x2+nx;
	      Dibujar();
	      ver=1;
	}

void Linea :: Movery (int ny)
	{
	      if(ver)
		  Ocultar();
	      y=x+ny;
	      y2=y2+ny;
	      Dibujar();
	      ver=1;
	}

void Linea :: Expandex(int e)
	{
	      Ocultar();
	      y=y-e;
	      //y2=y2+e;
	      Dibujar();
	      ver=1;
	}

void Linea :: Expandey(int e)
	{
	      Ocultar();
	      x=x-e;
	      Dibujar();
	      ver=1;
	}

void main()
{

     int a,b,i;
     a=DETECT;
     initgraph(&a,&b," ");
     Linea L1(10,10,10,50),L2(10,50,50,50), L3(50,50,10,10);      //Triangulo Rectangulo
     Linea L4(200,200,175,250),L5(175,250,225,250), L6(225,250,200,200);
     Linea L7(400,10,300,50),L8(300,50,380,100), L9(380,100,400,10);
     L1.Dibujar();
     L2.Dibujar();
     L3.Dibujar();
     L4.Dibujar();
     L5.Dibujar();
     L6.Dibujar();
     L7.Dibujar();
     L8.Dibujar();
     L9.Dibujar();
     getch();
     closegraph();
}
