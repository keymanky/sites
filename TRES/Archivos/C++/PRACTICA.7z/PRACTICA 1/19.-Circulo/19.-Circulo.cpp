#include <iostream.h>
#include <conio.h>
#include <graphics.h>
#include <dos.h>

class Circulo
{
      private:
	      int x,y,radio,ver,c;
	      float pi;
      public:
	      Circulo(int, int, int);
	      float Area();
	      float Perimetro();
	      void Dibujar(int);
	      void Ocultar();
	      void Mover(int, int);
	      void Expande(int);
};


Circulo :: Circulo(int ox=320,int oy=240, int orad=19)
	{
	      radio=orad;
	      x=ox;
	      y=oy;
	      pi=3.14159;
	      ver=0;
	      c=15;
	}


float Circulo :: Area()
	{
	      return (pi*radio*radio);
	}


float Circulo ::Perimetro()
	{
	      return (pi*2*radio);
	}


void Circulo :: Dibujar(int color=15)
	{
	      c=color;
	      setcolor(color);
	      circle(x,y,radio);
	      ver=1;
	}


void Circulo :: Ocultar()
	{
	      unsigned guardacolor;
	      guardacolor= getcolor();
	      int h=(getbkcolor());
	      Dibujar(h);
	      ver=0;
	      setcolor(guardacolor);
	}


void Circulo :: Mover(int nx,int ny)
	{
	      if(ver)
		  Ocultar();
	      x=nx;
	      y=ny;
	      Dibujar(c);
	      ver=1;
	}

void Circulo :: Expande(int e=0)
	{
	      Ocultar();
	      radio=radio+e;
	      Dibujar(c);
	      ver=1;
	}





void main()
{

     int a,b,i,j=1,k;
     a=DETECT;
     Circulo Cir1,Cir2;
     initgraph(&a,&b," ");
     Cir1.Dibujar();
     Cir2.Dibujar();
     getch();
     for(i=1;i<640;i++)
     {

	if(k==14)
	    k=0;
	Cir1.Dibujar(k);
	Cir2.Dibujar(k+1);
	k++;
	Cir1.Mover(i,160);
	Cir2.Mover(640-i,320);
	if(i%50==0)
	    {
	    Cir1.Expande(j);
	    Cir2.Expande(j);
	    j++;
	    }
	delay(5);
     }
     Cir1.Dibujar(k++);
     Cir2.Dibujar(k++);
     getch();
     closegraph();
}
